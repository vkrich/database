  function Status(s)
  {
    //var status=document.getElementById("status");
    //status.innerHTML=s;
  }

  function str_replace(suchen,ersetzen,string)
  {
    ausgabe = "" + string;
    var i=0;
    var pos=0;
    var abpos=0;
    while(ausgabe.indexOf(suchen,abpos)>-1)
    {
      pos=ausgabe.indexOf(suchen,abpos);

      if(pos>-1)
      {
        ausgabe=""+(ausgabe.substring(0,pos)+ersetzen+
        ausgabe.substring((pos+suchen.length),ausgabe.length));
      }

      abpos=pos+ersetzen.length;

      if(i>10)
        break;

      i++;
    }

    return ausgabe;
  }

  function strpos(s,ss)
  {
    var j;

    for(var i=1;i<s.length+1;i++)
    {
      for(j=0;j<ss.length;j++)
        if(s.charAt(i+j-1)!=ss.charAt(j))
          break;

      if(j==ss.length)
        return i;
    }
  }

  function JXMLHttp()
  {
    var xmlHttp = false;
    var ID;
    var Form;
    var i;

    var work=false;
    var LastAction;

    this.Request=Request;
    this.Add=Add;
    this.RequestLastAction=RequestLastAction;
    this.RequestNextAction=RequestNextAction;
    this.GetXMLHttpRequest=GetXMLHttpRequest;

    var Spooler=new Array();
    var SpoolerCursor=0;
    var SpoolerMaxCursor=0;

    i=0;
    var LockAction=new Array();
    LockAction[i++]="action=OnClick";
    LockAction[i++]="action--eq--OnClick";
    //LockAction[i++]="action=first";
    //LockAction[i++]="action=prev";
    //LockAction[i++]="action=next";
    //LockAction[i++]="action=last";

    //__construct();
    function GetXMLHttpRequest()
    {
      if (typeof(XMLHttpRequest) != 'undefined') {
          xmlHttp = new XMLHttpRequest();
      }
      if (!xmlHttp) {
          // Internet Explorer 6 und �lter
          try {
              xmlHttp  = new ActiveXObject("Msxml2.XMLHTTP");
          } catch(e) {
              try {
                  xmlHttp  = new ActiveXObject("Microsoft.XMLHTTP");
              } catch(e) {
                  xmlHttp  = false;
              }
          }
      }

      return xmlHttp;
    }

    function Add(action)
    {
      //if(SpoolerMaxCursor-SpoolerCursor<4)
      {
        Spooler[SpoolerMaxCursor]=action;
        SpoolerMaxCursor++;
      }

      window.status=SpoolerCursor+"/"+SpoolerMaxCursor;
    }

    function RequestNextAction()
    {
      if(SpoolerCursor<SpoolerMaxCursor)
      {
        //alert("ok");
        //var action=Spooler[SpoolerCursor];
        //alert(action+"Id1:"+this.ID+"/Id2:"+ID);

        //SpoolerCursor++;
        //window.status=SpoolerCursor+"/"+SpoolerMaxCursor;
        this.Request('stack');
      }
    }

    function RequestLastAction()
    {
      this.Request(this.LastAction);
    }

    function Request(action,withoutwork)
    {
      this.LastAction=action;

      //if(!withoutwork)
        withoutwork=false;

      //withoutwork=true;
      debug(action);
      //alert(action);

      Status("Send...");

      //alert(xmlHttp.onreadystatechange);

      //if(Math.random()<0.1)
      //  work=false;

      //work=false;
      if(work && !withoutwork)
        this.Add(action);
      else if(work==false || withoutwork)
      {
          work=true;
          var Form=this.Form;
          var xml="";

          var xmlHttp=this.GetXMLHttpRequest();
          if (xmlHttp)
          {
            debug("post");

            var inner_xml="";
            if(action=="stack")
            {
              var i_start=SpoolerCursor;
              var i_end=SpoolerMaxCursor;
              for(var i=i_start;i<i_end;i++)
              {
                action=Spooler[i];

                //for(var k=0;k<10;k++)
                while(strpos(action,"="))
                  action=action.replace(/=/,"--eq--");
                //while(strpos(action,"+"))
                //  action=action.replace(/\+/,"--add--");

                action=urlencode(action);

                //while(strpos(action,"&"))
                //  action=action.replace(/&/,"--and--");

                //inner_xml+='<a s="'+urlencode(action)+'"/>';
                //inner_xml+='<a s="'+urlencode(action)+'"/>';
                inner_xml+='<a s="'+action+'"/>';

                SpoolerCursor++;

                window.status=SpoolerCursor+"/"+SpoolerMaxCursor;
              }
              if(inner_xml)
                xml+='<r>'+inner_xml+'</r>';
            }
            else
            {
              while(strpos(action,"="))
                action=action.replace(/=/,"--eq--");
              //while(strpos(action,"+"))
              //  action=action.replace(/\+/,"--add--");

              //xml='<r><a s="'+urlencode(action)+'"></a></r>';
              action=urlencode(action);
              //alert(action);
              xml='<r><a s="'+action+'"></a></r>';

            }

            var action_str='license='+this.License+'&ajax=1&id='+this.ID+'&xml='+xml; //+'&'+action;

            //alert(xml);
            //alert(LockAction.length);

            var output=document.getElementById("output");
            output.value+=action_str+'\n\n';

            for(i=0;i<LockAction.length;i++)
            {
              if(strpos(xml,LockAction[i]))
              {
                var lock=document.getElementById("lock"+this.Form.toUpperCase());
                lock.style.zIndex=10;
              }
            }

            //alert(action_str);

            //alert(this.Script);
            xmlHttp.open('POST', this.Script, true);
            xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
            xmlHttp.setRequestHeader("Pragma", "no-cache");
            xmlHttp.setRequestHeader("Expires", "0");
            xmlHttp.setRequestHeader("Cache-Control", "no-store");

            xmlHttp.onreadystatechange = function () {
                if (xmlHttp.readyState == 4)
                {
                  Status("Working...");

                  work=false;
                  //alert(xmlHttp.responseXML.document);
                  debug("antwort:"+xmlHttp.responseText);
                  //alert("antwort:"+xmlHttp.responseText);
                  if(strpos(xmlHttp.responseText,"Parse error"))
                    alert(xmlHttp.responseText);

                  if(xmlHttp.responseXML)
                  {
                    try
                    {
                      var output=document.getElementById("output");
                      output.value+=xmlHttp.responseText+'\n\n';

                      var xml=xmlHttp.responseXML.documentElement;
                      if(!xml)
                      {
                        //if(xmlHttp.responseText)
                        //  alert(xmlHttp.responseText);
                      }
                      else
                      for(i=0;i<xml.childNodes.length;i++)
                      {
                        var node=xml.childNodes[i];
                        if(node.nodeName=="js")
                        {
                          if(node.text)
                            eval(node.text);
                          else
                            eval(node.childNodes[0].nodeValue);
                        }
                        else if(node.nodeName=="ma")
                        {
                          var o=document.getElementById(node.getAttribute("id"));

                          if(o)
                          {
                            //alert(node.getAttribute("id"));
                            if(node.text)
                              v=node.text;
                            else
                              v=node.childNodes[0].nodeValue;

                            if(node.getAttribute("c")=="base64")
                              v=decodeBase64(v);

                            if(node.getAttribute("a")=="value")
                              o.value=v;
                            else if(node.getAttribute("a")=="caption")
                              o.innerHTML=v;
                            else if(node.getAttribute("a")=="richedit")
                            {
                              o.value=v;
                              MySPAW_editorInit(node.getAttribute("id"), '', 'ltr')
                            }
                            else if(node.getAttribute("a")=="image")
                              o.src=v;
                            else if(node.getAttribute("a")=="setter")
                            {
                              //alert(node.getAttribute("id")+"Setter("+v+")");
                              //alert(node.getAttribute("id")+'Setter(\''+v+'\');');
                              eval(node.getAttribute("id")+'Setter(\''+v+'\');');
                            }
                          }
                          else
                            alert("Objekt mit der ID \""+node.getAttribute("id")+"\" nicht gefunden!");
                        }

                      }
                    }
                    catch (e)
                    {
                      alert("error: ("+e+")"+xmlHttp.responseText);
                      var status=document.getElementById("status");
                      status.innerHTML="error";
                    }

                    Status("ok");

                    setTimeout(Form+"Server.RequestNextAction();",1);
                    setTimeout("var status=document.getElementById('status'); if(status.innerHTML=='ok') status.innerHTML='';",1000);

                    //alert(xmlHttp.responseText.ContentType);

                    //eval(xmlHttp.responseText);
                    //eval("document.getElementById('oLabel1').style.left='10px';document.getElementById('oLabel2').style.left='10px'; ");
                  }
                  else if(xmlHttp.responseText)
                  {
                    alert(xmlHttp.responseText);
                  }
                  else
                  {
                    Status("no response");

                    //setTimeout(Form+"Server.RequestLastAction();",1000);
                  }

                  var lock=document.getElementById("lock"+Form.toUpperCase());
                  lock.style.zIndex=-10;
                }

              }

              Status("Loading...");
              xmlHttp.send(action_str);

          };
      }
    }
  }