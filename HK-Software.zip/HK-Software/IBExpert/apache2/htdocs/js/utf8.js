        function utf8_encode(rohtext) {
             // dient der Normalisierung des Zeilenumbruchs
             rohtext = rohtext.replace(/\r\n/g,"\n");
             var utftext = "";
             for(var n=0; n<rohtext.length; n++)
                 {
                 // ermitteln des Unicodes des  aktuellen Zeichens
                 var c=rohtext.charCodeAt(n);
                 // alle Zeichen von 0-127 => 1byte
                 if (c<128)
                     utftext += String.fromCharCode(c);
                 // alle Zeichen von 127 bis 2047 => 2byte
                 else if((c>127) && (c<2048)) {
                     utftext += String.fromCharCode((c>>6)|192);
                     utftext += String.fromCharCode((c&63)|128);}
                 // alle Zeichen von 2048 bis 66536 => 3byte
                 else {
                     utftext += String.fromCharCode((c>>12)|224);
                     utftext += String.fromCharCode(((c>>6)&63)|128);
                     utftext += String.fromCharCode((c&63)|128);}
                 }
             return utftext;
         }
/*
00:        function decode_utf8(utftext) {
01:             var plaintext = ""; var i=0; var c=c1=c2=0;
02:             // while-Schleife, weil einige Zeichen uebersprungen werden
03:             while(i<utftext.length)
04:                 {
05:                 c = utftext.charCodeAt(i);
06:                 if (c<128) {
07:                     plaintext += String.fromCharCode(c);
08:                     i++;}
09:                 else if((c>191) && (c<224)) {
10:                     c2 = utftext.charCodeAt(i+1);
11:                     plaintext += String.fromCharCode(((c&31)<<6) | (c2&63));
12:                     i+=2;}
13:                 else {
14:                     c2 = utftext.charCodeAt(i+1); c3 = utftext.charCodeAt(i+2);
15:                     plaintext += String.fromCharCode(((c&15)<<12) | ((c2&63)<<6) | (c3&63));
16:                     i+=3;}
17:                 }
18:             return plaintext;
19:         }


*/

