  /*  Context Menu script II (By Dheera Venkatraman at dheera@usa.net)
  Submitted to Dynamic Drive to feature script in archive
  For full source, usage terms, and 100's more DHTML scripts, visit http://dynamicdrive.com
  */

  var isie=0;
  if(window.navigator.appName=="Microsoft Internet Explorer"&&window.navigator.appVersion.substring(window.navigator.appVersion.indexOf("MSIE")+5,window.navigator.appVersion.indexOf("MSIE")+8)>=5.5)
  {
    isie=1;
  }
  else
  {
    isie=0;
  }

  function create_html()
  {
    var html="<html>"+
             "<head>"+
             ""+
             "  <style type='text/css'>"+
             "    .menuitem"+
             "    {"+
             "      font-family:Arial;"+
             "    }"+
             "    body { background-color:red;}"+
             "    td { background-color:green;}"+
             "  </style>"+
             ""+
             "</head>"+
             "<body>";

    html+='<table style="border:1pt solid black" bgcolor="#f0f0f0" width="160" height="220" cellpadding="0" cellspacing="1">';
    html+='<st'+'yle type="text/css">\n';
    html+='a:link {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
    html+='a:visited {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
    html+='td {font-size:8pt;}\n';
    html+='<\/style>\n';
    html+='<sc'+'ript type="txt/javascript">\n';
    html+='\n<'+'!--\n';
    html+='window.onerror=null;\n';
    html+='/'+' -'+'->\n';
    html+='<\/script>\n';

    //if(parent.node)
    //  html+='<tr><td  id="i9" onmouseover="document.all.i9.style.background=\'#CFD6E8\';document.all.i9.style.border=\'1pt solid #737B92\';" onmouseout="document.all.i9.style.background=\'#f0f0f0\';document.all.i9.style.border=\'1pt solid #f0f0f0\';" onclick="if(window.parent.document.body.style.zoom!=0) window.parent.document.body.style.zoom*=0.625; else window.parent.document.body.style.zoom=0.625;"> <img src="js/rightmouse_personal_ie55_zoom.gif" width="12" height="12" border="0" hspace="0" vspace="0" align="absmiddle"> Zoom Out<\/td><\/tr>';

    var item=Array();

    var ii=0;
    if(node)
    {
      //alert(url);
      item[0]=Array();

      item[0]['text']=" Alles �ffnen";
      item[0]['onclick']="parent.location.href=\""+url+"\"";

      ii=1;
    }


    item[0+ii]=Array();
    item[1+ii]=Array();
    item[2+ii]=Array();
    item[3+ii]=Array();
    item[4+ii]=Array();
    item[5+ii]=Array();
    item[6+ii]=Array();
    item[7+ii]=Array();
    item[8+ii]=Array();
    item[9+ii]=Array();

    item[0+ii]['text']=" Zur�ck";
    item[0+ii]['onclick']="window.parent.history.go(-1);";

    item[1+ii]['text']=" Vor";
    item[1+ii]['onclick']="window.parent.history.go(1);";

    item[2+ii]['text']=" Zu Favorieten hinzuf�gen";
    item[2+ii]['onclick']="window.parent.external.AddFavorite(window.top.location.href,window.top.document.title);";

    item[3+ii]['text']=" Quelltext anzeigen";
    item[3+ii]['onclick']="window.parent.location=\"view-source:\"+window.parent.location.href;";

    item[4+ii]['text']=" Seite Drucken";
    item[4+ii]['onclick']="window.print();";

    item[5+ii]['text']=" aktualisieren";
    item[5+ii]['onclick']="window.parent.location.href=window.parent.location.href;";

    item[6+ii]['text']=" Zoom In";
    item[6+ii]['onclick']="if(window.parent.document.body.style.zoom!=0) window.parent.document.body.style.zoom*=1.6; else window.parent.document.body.style.zoom=1.6;";

    item[7+ii]['text']=" Zoom Out";
    item[7+ii]['onclick']="if(window.parent.document.body.style.zoom!=0) window.parent.document.body.style.zoom*=0.625; else window.parent.document.body.style.zoom=0.625;";

    item[8+ii]['text']="";
    item[8+ii]['onclick']="";

    item[9+ii]['text']="";
    item[9+ii]['onclick']="";

    style="font-family:Arial; border:1px solid #f0f0f0; height:20px;";

    for(i=0;i<8;i++)
    {
      text="<nobr>"+item[i]['text']+"<nobr>";
      onclick=item[i]['onclick'];
      image=item[i]['image'];
      image="";

      //html+="<tr><td style='"+style+"' id='i"+i+"' onmouseover='document.all.i"+i+".style.background=\"#CFD6E8\";document.all.i"+i+".style.border=\"1pt solid #737B92\";' onmouseout='document.all.i"+i+".style.background=\"#f0f0f0\";document.all.i"+i+".style.border=\"1pt solid #f0f0f0\";' onclick='"+onclick+"'> <img src='js/rightmouse_personal_ie55_back.gif' width='12' height='12' border='0' hspace='0' vspace='0' align='absmiddle'>"+text+"<\/td><\/tr>";
      html+="<tr><td style='"+style+"' id='i"+i+"' onmouseover='document.all.i"+i+".style.background=\"#CFD6E8\";document.all.i"+i+".style.border=\"1pt solid #737B92\";' onmouseout='document.all.i"+i+".style.background=\"#f0f0f0\";document.all.i"+i+".style.border=\"1pt solid #f0f0f0\";' onclick='"+onclick+"'>&nbsp;&nbsp;"+text+"<\/td><\/tr>";
    }

    html+='</table></body></html>';

    node=0;

    return html;
  }

  if(isie)
    var oPopup = window.createPopup();

  function dopopup(x,y)
  {
    if(isie)
    {
      var oPopupBody = oPopup.document.body;
      oPopupBody.innerHTML = create_html();
      oPopup.show(x, y, 160,220, document.body);
    }
  }

  function click(e)
  {
    if(isie)
    {
       if(document.all)
       {
         if(event.button==2||event.button==3)
         {
           dopopup(event.x-1,event.y-1);
         }
       }
    }
  }

  if(isie)
  {

    function contextmenu()
    {
      dopopup(event.x,event.y);
      return false;
    }
    //document.onmousedown = click;
  }