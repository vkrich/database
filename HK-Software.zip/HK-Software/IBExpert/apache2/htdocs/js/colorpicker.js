  function showColorPicker(curcolor,element)
  {
    var newcol = showModalDialog('include/colorpicker/colorpicker.php', curcolor, 'dialogHeight:250px; dialogWidth:366px; resizable:no; status:no');


    try
    {
      element.value=newcol;
      element.style.backgroundColor=newcol;
    }
    catch (excp) {}
  }

