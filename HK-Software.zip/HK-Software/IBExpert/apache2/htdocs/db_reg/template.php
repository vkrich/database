<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  $db_index=0;
  $c['db'][$db_index]['db_file']="{connectstring}";
  $c['db'][$db_index]['db_user']="{username}";
  $c['db'][$db_index]['db_pass']="{password}";


?>