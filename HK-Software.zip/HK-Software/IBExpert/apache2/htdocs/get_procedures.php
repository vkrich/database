<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  include("include/PDB.php");
  include("include/config.php");

  $db=new PDB();

  $sql="select ibe\$script_form form from ibe$scripts";
  $db->query();
  while($db->fetch())
  {
    echo $db->Row['FORM']."<br>";
  }

?>