<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TColumnTitle
  {
    function __construct()
    {
      $this->Color=mapcolor("clBtnFace");
    }

  }

?>