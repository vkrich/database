<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TTest
  {
    function TTest()
    {
      $this->db=new PDB();

      if(!$theme)
        $theme="standard";

      $this->Theme=$theme;
      $this->ActionStack=$action_stack;

      /*
      $fh=fopen($dfm_file,"r");
      $this->dfm=fread($fh,filesize($dfm_file));
      fclose($fh);
      */

      $this->dfm=$dfm;
      //$this->parse();
    }
  }

?>