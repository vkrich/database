<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TFont
  {
    function TFont()
    {
      $this->Height=-11;
      $this->Name="Ms Sans Serif";
      $this->Name="Verdana";
      $this->Name="Tahoma";
    }

  }

?>