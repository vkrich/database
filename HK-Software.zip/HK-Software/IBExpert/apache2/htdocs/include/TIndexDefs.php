<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TIndexDefs extends TObject
  {
    function __construct($owner)
    {
      parent::__construct($owner);
    }
  }

?>