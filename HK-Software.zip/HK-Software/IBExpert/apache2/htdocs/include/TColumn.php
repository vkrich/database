<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TColumn extends TObject
  {
    var $Width;
    var $Visible;

    function __construct($owner)
    {
      parent::__construct($owner);
    }
  }

?>