<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class TDBText extends TControl
  {
    var $datasource;
    var $dataset;

    function __construct($owner=null)
    {
      parent::__construct($owner);
    }

    function Init()
    {
      parent::Init();
      
      if($this->DataSource)
        $this->datasource=$this->GetComponentByName($this->DataSource);
      if($this->datasource->DataSet)
        $this->dataset=$this->GetComponentByName($this->datasource->DataSet);
    }

    function Set($attribute,$value)
    {
      if($attribute=="LINES_TEXT")
      {
        $value=str_replace("<","&lt;",$value);
        $value=str_replace(">","&gt;",$value);
        $value=str_replace(CRLF,"<br>",$value);
        $value=str_replace(" ","&nbsp;",$value);

        $this->ca->ModifyAttribute($this,"caption",$value);
      }
    }

    function Get()
    {
      parent::Get();

      if(!$this->Font)
        $this->Font=new TFont();

      return str_replace("{content}",$this->ThemeTemplate->Get(),$this->Template);
    }

  }

?>