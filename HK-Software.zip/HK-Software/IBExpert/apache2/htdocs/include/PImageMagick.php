<?php

// IBExpertWebForms
// copyright  �  2006-2008 Holger Klemt hklemt@ibexpert.biz
// www.ibexpert.com


  class PImageMagick
  {
    var $im_bin;
    var $dir;

    function PImageMagick()
    {
      global $ca,$script_dir;

      $this->dir=str_replace("\\","/",$script_dir);
      $this->im_bin="C:/Program Files (x86)/ImageMagick-6.2.9-Q16";
      $this->im_bin="C:/im";
    }

    function Render()
    {
      global $ca;

      //$ca->alert($this->dir);

      $exec_str=$this->im_bin."/convert -resize ".$this->Size." \"".$this->dir."/".$this->Source."\" \"".$this->dir."/".$this->Dest."\"";
      //$exec_str="notepad";

      $ret=exec($exec_str);

      //echo $exec_str."<br>";
      //$ca->alert($exec_str);

    }

  }

?>